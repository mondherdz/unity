using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class playerController : MonoBehaviour {
    private Rigidbody rb;
    public float speed;
    public int count;
    public Text counting;
    public Text win;
    
    void Start(){
        rb = GetComponent<Rigidbody>();
        
        count = 0;
        settingCount();
        win.text = "";
    }
    
    void FixedUpdate(){
        float mooveH = Input.GetAxis("Horizontal");
        float mooveV = Input.GetAxis("Vertical");
        
        Vector3 movement = new Vector3 (mooveH, 0.0f, mooveV);
        
        rb.AddForce(movement * speed);
    }
    
    void OnTriggerEnter(Collider other){
        if(other.gameObject.CompareTag("pickeable")){
            other.gameObject.SetActive(false);
            count = count + 1;
            settingCount();
        }
    }
    
    void settingCount(){
        counting.text = "Cubes eaten : " + count;
        if(count >= 8 ){
            win.text = "*You Win*" ;
        }
    }
}

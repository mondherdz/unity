using UnityEngine;
using System.Collections;

public class cube : MonoBehaviour {
    private Rigidbody rigid;
    public float acce;

	// Use this for initialization
	void Start () {
	   rigid = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update () {
        float verti = Input.GetAxis("Vertical");
        float hori = Input.GetAxis("Horizontal");
        
        Vector3 v3 = new Vector3 (hori, 0.0f, verti);
        rigid.AddForce(v3 * acce);
        
	}
}
